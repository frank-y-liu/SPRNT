#include "cs.h"
#ifndef EXTERN
#define EXTERN extern
#endif
EXTERN int malloc_count ;
